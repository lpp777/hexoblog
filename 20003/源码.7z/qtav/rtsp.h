#ifndef RTSP_H
#define RTSP_H

#include <QtAVWidgets>
#include <QtAV>

namespace Ui {
class rtsp;
}

class rtsp : public QWidget
{
    Q_OBJECT

public:
    explicit rtsp(QWidget *parent = 0);
    ~rtsp();

private slots:
    void on_B1_clicked();

    void on_B2_clicked();

    void on_B3_clicked();

    void on_B4_clicked();

private:
    Ui::rtsp *ui;
    QtAV::VideoOutput *m_vo1;
    QtAV::VideoOutput *m_vo2;
    QtAV::VideoOutput *m_vo3;
    QtAV::VideoOutput *m_vo4;
    QtAV::AVPlayer *m_player1;
    QtAV::AVPlayer *m_player2;
    QtAV::AVPlayer *m_player3;
    QtAV::AVPlayer *m_player4;

    bool p1,p2,p3,p4;


};

#endif // RTSP_H
