#include "rtsp.h"
#include "ui_rtsp.h"


rtsp::rtsp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rtsp)
{
    ui->setupUi(this);
//"FFmpeg", "CUDA", "DXVA", "D3D11", "VAAPI", "VDA", "VideoToolbox"
    m_player1 = new QtAV::AVPlayer(this);
    m_player1->setVideoDecoderPriority(QStringList() << "FFmpeg" );
    m_player2 = new QtAV::AVPlayer(this);
    m_player2->setVideoDecoderPriority(QStringList() << "FFmpeg" );
    m_player3 = new QtAV::AVPlayer(this);
    m_player3->setVideoDecoderPriority(QStringList() << "D3D11" );
    m_player4 = new QtAV::AVPlayer(this);
    m_player4->setVideoDecoderPriority(QStringList() << "FFmpeg" );

    m_vo1 = new QtAV::VideoOutput(this);
    m_vo2 = new QtAV::VideoOutput(this);
    m_vo3 = new QtAV::VideoOutput(this);
    m_vo4 = new QtAV::VideoOutput(this);

    m_player1->setRenderer(m_vo1);
    m_player2->setRenderer(m_vo2);
    m_player3->setRenderer(m_vo3);
    m_player4->setRenderer(m_vo4);

    ui->videolayout->addWidget(m_vo1->widget(),0,0);
    ui->videolayout->addWidget(m_vo2->widget(),0,1);
    ui->videolayout->addWidget(m_vo3->widget(),1,0);
    ui->videolayout->addWidget(m_vo4->widget(),1,1);


    p1=true;p2=true;p3=true;p4=true;

}

rtsp::~rtsp()
{
    delete ui;
}



void rtsp::on_B1_clicked()
{
    if(p1)
    {
        m_player1->play("rtsp://192.168.1.3:8554/xiao.mkv");
        p1=!p1;
    }
    else
    {
        m_player1->stop();
        p1=!p1;
    }
}

void rtsp::on_B2_clicked()
{

    if(p2)
    {
        m_player2->play("rtsp://192.168.1.3:8554/2.mkv");
        p2=!p2;
    }
    else
    {
        m_player2->stop();
        p2=!p2;
    }
}

void rtsp::on_B3_clicked()
{

    if(p3)
    {
        m_player3->play("rtsp://192.168.1.3:8554/3.mkv");
        p3=!p3;
    }
    else
    {
        m_player3->stop();
        p3=!p3;
    }
}

void rtsp::on_B4_clicked()
{
    if(p4)
    {
        m_player4->play("rtsp://192.168.1.3:8554/4.mkv");
        p4=!p4;
    }
    else
    {
        m_player4->stop();
        p4=!p4;
    }
}
