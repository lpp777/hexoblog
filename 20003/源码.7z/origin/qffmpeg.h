#ifndef QFFMPEG_H
#define QFFMPEG_H

#ifndef INT64_C
#define INT64_C
#define UINT64_C
#endif

extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavformat/avformat.h>
#include <libavfilter/avfilter.h>
#include <libswscale/swscale.h>
#include <libavutil/frame.h>
}


#include <QObject>
#include <QMutex>
#include <QImage>

class qffmpeg : public QObject
{
    Q_OBJECT
private:
    QString url;
    int videoWidth;
    int videoHeight;
    int videoStreamIndex;
    QMutex mutex;

    AVPicture  pAVPicture;
    AVFormatContext *pAVFormatContext;
    AVCodecContext *pAVCodecContext;
    AVFrame *pAVFrame;
    SwsContext * pSwsContext;
    AVPacket pAVPacket;
public:
    explicit qffmpeg(QObject *parent = nullptr);
    ~qffmpeg();

    bool Init();
    void Play();
    void SetUrl(QString url){this->url=url;}
    QImage videoframe;

signals:
    void GetImage(const QImage &image);

public slots:
};

#endif // QFFMPEG_H
