

#include "rtspthread.h"

rtspthread::rtspthread(QObject *parent) :
    QThread(parent)
{

}

void rtspthread::run()
{
    fmg->Play();
}
