#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <VLCQtCore/Common.h>
#include <VLCQtCore/Instance.h>
#include <VLCQtCore/Media.h>
#include <VLCQtCore/MediaPlayer.h>
#include <VLCQtCore/Audio.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    VlcWidgetVideo *v1=new VlcWidgetVideo(this);
    VlcWidgetVideo *v2=new VlcWidgetVideo(this);
    VlcWidgetVideo *v3=new VlcWidgetVideo(this);
    VlcWidgetVideo *v4=new VlcWidgetVideo(this);

    ui->gridLayout->addWidget(v1,0,0);
    ui->gridLayout->addWidget(v2,0,1);
    ui->gridLayout->addWidget(v3,1,0);
    ui->gridLayout->addWidget(v4,1,1);

    _instance = new VlcInstance(VlcCommon::args(), this);
    _player1 = new VlcMediaPlayer(_instance);
    _player1->setVideoWidget(v1);
    _player2 = new VlcMediaPlayer(_instance);
    _player2->setVideoWidget(v2);
    _player3 = new VlcMediaPlayer(_instance);
    _player3->setVideoWidget(v3);
    _player4 = new VlcMediaPlayer(_instance);
    _player4->setVideoWidget(v4);


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_B1_clicked()
{
    _media = new VlcMedia("rtsp://192.168.1.3:8554/xiao.mkv", _instance);
    _player1->open(_media);
    _player1->audio()->setVolume(100);
}

void MainWindow::on_B2_clicked()
{
    _media = new VlcMedia("rtsp://192.168.1.3:8554/2.mkv", _instance);
    _player2->open(_media);
    _player2->audio()->setVolume(100);
}

void MainWindow::on_B3_clicked()
{
    _media = new VlcMedia("rtsp://192.168.1.3:8554/3.mkv", _instance);
    _player3->open(_media);
    _player3->audio()->setVolume(100);
}

void MainWindow::on_B4_clicked()
{
    _media = new VlcMedia("rtsp://192.168.1.3:8554/4.mkv", _instance);
    _player4->open(_media);
    _player4->audio()->setVolume(100);
}
