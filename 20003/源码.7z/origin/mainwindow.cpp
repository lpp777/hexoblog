#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "qmessagebox.h"
#include "qffmpeg.h"
#include "rtspthread.h"
#include <qlabel.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
	v1 = new QLabel(this);
	v2 = new QLabel(this);
	v3 = new QLabel(this);
	v4 = new QLabel(this);
	ui->gridLayout->addWidget(v1, 0, 0);
	ui->gridLayout->addWidget(v2, 0, 1);
	ui->gridLayout->addWidget(v3, 1, 0);
	ui->gridLayout->addWidget(v4, 1, 1);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::B1()
{
    labImgW1= v1->rect().width();
    labImgH1= v1->rect().height();
	labImgW2 = v2->rect().width();
	labImgH2 = v2->rect().height();
	labImgW3 = v3->rect().width();
	labImgH3 = v3->rect().height();
	labImgW4 = v4->rect().width();
	labImgH4 = v4->rect().height();

    qffmpeg *f=new qffmpeg(this);
    connect( f, SIGNAL(GetImage(QImage)), this, SLOT(SetImage1(QImage)) );
    f->SetUrl("rtsp://192.168.1.3:8554/xiao.mkv");
    if(f->Init())
    {
        rtspthread *rthred=new rtspthread(this);
        rthred->setffmpeg(f);
        rthred->start();
    }



}
void MainWindow::B2()
{
	qffmpeg *f = new qffmpeg(this);
	connect(f, SIGNAL(GetImage(QImage)), this, SLOT(SetImage2(QImage)));
	f->SetUrl("rtsp://192.168.1.3:8554/2.mkv");
	if (f->Init())
	{
		rtspthread *rthred = new rtspthread(this);
		rthred->setffmpeg(f);
		rthred->start();
	}
}
void MainWindow::B3()
{
	qffmpeg *f = new qffmpeg(this);
	connect(f, SIGNAL(GetImage(QImage)), this, SLOT(SetImage3(QImage)));
	f->SetUrl("rtsp://192.168.1.3:8554/3.mkv");
	if (f->Init())
	{
		rtspthread *rthred = new rtspthread(this);
		rthred->setffmpeg(f);
		rthred->start();
	}
}
void MainWindow::B4()
{
	qffmpeg *f = new qffmpeg(this);
	connect(f, SIGNAL(GetImage(QImage)), this, SLOT(SetImage4(QImage)));
	f->SetUrl("rtsp://192.168.1.3:8554/4.mkv");
	if (f->Init())
	{
		rtspthread *rthred = new rtspthread(this);
		rthred->setffmpeg(f);
		rthred->start();
	}
}


void MainWindow::SetImage1(const QImage &image)
{
    if (image.height()>0){
        //QPixmap pix = QPixmap::fromImage(image);
       QPixmap pix = QPixmap::fromImage(image.scaled(labImgW1,labImgH1));
        v1->setPixmap(pix);
    }
}
void MainWindow::SetImage2(const QImage &image)
{
	if (image.height()>0) {
		//QPixmap pix = QPixmap::fromImage(image);
		QPixmap pix = QPixmap::fromImage(image.scaled(labImgW1, labImgH1));
		v2->setPixmap(pix);
	}
}
void MainWindow::SetImage3(const QImage &image)
{
	if (image.height()>0) {
		//QPixmap pix = QPixmap::fromImage(image);
		QPixmap pix = QPixmap::fromImage(image.scaled(labImgW1, labImgH1));
		v3->setPixmap(pix);
	}
}
void MainWindow::SetImage4(const QImage &image)
{
	if (image.height()>0) {
		//QPixmap pix = QPixmap::fromImage(image);
		QPixmap pix = QPixmap::fromImage(image.scaled(labImgW1, labImgH1));
		v4->setPixmap(pix);
	}
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type()==QEvent::Resize){

    }
    return QObject::eventFilter(obj,event);
}

/*
void MainWindow::on_pushButton_2_clicked()
{
    qffmpeg *f=new qffmpeg(this);
    connect( f, SIGNAL(GetImage(QImage)), this, SLOT(SetImage(QImage)) );
    f->SetUrl(ui->url->text());
    f->Init();
    f->Play();
}
*/
