#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <VLCQtWidgets/WidgetVideo.h>

class VlcInstance;
class VlcMedia;
class VlcMediaPlayer;


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_B1_clicked();

    void on_B2_clicked();

    void on_B3_clicked();

    void on_B4_clicked();

private:
    Ui::MainWindow *ui;

    VlcInstance *_instance;
    VlcMedia *_media;
    VlcMediaPlayer *_player1;
    VlcMediaPlayer *_player2;
    VlcMediaPlayer *_player3;
    VlcMediaPlayer *_player4;
};

#endif // MAINWINDOW_H
