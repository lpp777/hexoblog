#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <qlabel.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void B1();
	void B2();
	void B3();
	void B4();
    void SetImage1(const QImage &image);
	void SetImage2(const QImage &image);
	void SetImage3(const QImage &image);
	void SetImage4(const QImage &image);

private:
    Ui::MainWindow *ui;

	QLabel *v1;
	QLabel *v2;
	QLabel *v3;
	QLabel *v4;

    int labImgW1;
    int labImgH1;
	int labImgW2;
	int labImgH2;
	int labImgW3;
	int labImgH3;
	int labImgW4;
	int labImgH4;

protected:
    bool eventFilter(QObject *obj, QEvent *event);
};

#endif // MAINWINDOW_H
