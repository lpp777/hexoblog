#ifndef RTSPTHREAD_H
#define RTSPTHREAD_H

#include <QThread>
#include "qffmpeg.h"

class rtspthread : public QThread
{
    Q_OBJECT
private:
    qffmpeg *fmg;
public:
    explicit rtspthread(QObject *parent = 0);
    void run();
    void setffmpeg(qffmpeg *f){fmg=f;};

signals:

};

#endif // RTSPTHREAD_H
